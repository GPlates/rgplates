# Change log of the R package 'rgplates

## [0.1.0] - 2021-05-11 (build 1)
### Added 
- material copied over from chronosphere 0.4.1 

### Changed
- platemodel data example is manually extracted

